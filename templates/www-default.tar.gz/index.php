<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>https://##DOMAIN##/</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="##DOMAIN##" />
    <meta name="keywords" content="##DOMAIN##" />
    <meta content="##DOMAIN##" name="author" />
    <link rel="shortcut icon" href="dist/images/favicon.png">
    <link href="dist/css/pe-icon-7.css" rel="stylesheet" type="text/css" />
    <link href="dist/css/owl.carousel.min.css" type="text/css" type="text/css" />
    <link href="dist/css/owl.theme.default.min.css" type="text/css" type="text/css" />
    <link href="dist/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="dist/css/style.min.css" rel="stylesheet" type="text/css" />
</head>
<?php
$BaseURL="https://##LINK##/";
?>
<body>

    <div id="preloader">
        <div id="status">
            <div class="spinner">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark align-items-center" style="background-image: url(dist/images/hero-1-bg-img.png)">
        <div class="container">
            <a class="logo mr-3" href="<?php echo $BaseURL ?>">
                <img src="dist/images/logo.png" alt="" class="" height="40">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="" data-feather="menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav navbar-center" id="mySidenav">
                    <li class="nav-item active">
                        <a href="#home" class="nav-link"><strong>Home</strong></a>
                    </li>
                </ul>

                <ul class="list-inline ml-auto menu-social-icon mb-0 py-2 py-lg-0">
                    <li class="list-inline-item ml-0">
                        <a href="#" class="menu-social-link"><i class="icon-xs sw_1-5" data-feather="facebook"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#" class="menu-social-link"><i class="icon-xs sw_1-5" data-feather="twitter"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#" class="menu-social-link"><i class="icon-xs sw_1-5" data-feather="instagram"></i></a>
                    </li>
                    <li class="list-inline-item mr-0">
                        <a href="#" class="menu-social-link"><i class="icon-xs sw_1-5" data-feather="linkedin"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="hero-1-bg bg-light" id="home">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="text-center mb-5">
                        <h1 class=""><b>Welcome to ##DOMAIN##</b></h1>
                        <h2 class="">Our Services</h2>
                        <P class="text-muted">Some list of services you can use.</P>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="card service-box text-center p-4" style="background-image: url(dist/images/hero-1-bg-img.png);background-size: contain;">
                        <div class="service-icon-bg mx-auto avatar-xxl p-4" style="background-image: url(dist/images/pma.png)">
                        </div>
                        <h4 class="service-title mt-4 mb-3 f-18"><b>PhpMyAdmin</b></h4>
                        <p class="service-subtitle mb-4 f-15">Web-based database manager</p>
                        <a href="<?php echo $BaseURL.'phpmyadmin/' ?>" target="_blank" class="read-more">Open<span class="right-icon ml-2">&#8594;</span></a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card service-box text-center p-4" style="background-image: url(dist/images/hero-1-bg-img.png);background-size: contain;">
                        <div class="service-icon-bg mx-auto avatar-xxl p-4" style="background-image: url(dist/images/f.png)">
                        </div>
                        <h4 class="service-title mt-4 mb-3 f-18"><b>File Manager</b></b></h4>
                        <p class="service-subtitle mb-4 f-15">Web-based file and folder manager</p>
                        <a href="<?php echo $BaseURL.'filemanager/' ?>" target="_blank" class="read-more">Open<span class="right-icon ml-2">&#8594;</span></a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card service-box text-center p-4" style="background-image: url(dist/images/hero-1-bg-img.png);background-size: contain;">
                        <div class="service-icon-bg mx-auto avatar-xxl p-4" style="background-image: url(dist/images/c.png)">
                        </div>
                        <h4 class="service-title mt-4 mb-3 f-18"><b>Coming Soon</b></h4>
                        <p class="service-subtitle mb-4 f-15">Look forward to our next service</p>
                        <a href="<?php echo $BaseURL ?>" target="_blank" class="read-more">Open<span class="right-icon ml-2">&#8594;</span></a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="card service-box text-center p-4" style="background-image: url(dist/images/hero-1-bg-img.png);background-size: contain;">
                        <div class="service-icon-bg mx-auto avatar-xxl p-4" style="background-image: url(dist/images/c.png)">
                        </div>
                        <h4 class="service-title mt-4 mb-3 f-18"><b>Coming Soon</b></h4>
                        <p class="service-subtitle mb-4 f-15">Look forward to our next service</p>
                        <a href="<?php echo $BaseURL ?>" target="_blank" class="read-more">Open<span class="right-icon ml-2">&#8594;</span></a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card service-box text-center p-4" style="background-image: url(dist/images/hero-1-bg-img.png);background-size: contain;">
                        <div class="service-icon-bg mx-auto avatar-xxl p-4" style="background-image: url(dist/images/c.png)">
                        </div>
                        <h4 class="service-title mt-4 mb-3 f-18"><b>Coming Soon</b></h4>
                        <p class="service-subtitle mb-4 f-15">Look forward to our next service</p>
                        <a href="<?php echo $BaseURL ?>" target="_blank" class="read-more">Open<span class="right-icon ml-2">&#8594;</span></a>
                    </div>
                </div>
                <div class="col-lg-4"> 
                    <div class="card service-box text-center p-4" style="background-image: url(dist/images/hero-1-bg-img.png);background-size: contain;">
                        <div class="service-icon-bg mx-auto avatar-xxl p-4" style="background-image: url(dist/images/c.png)">
                        </div>
                        <h4 class="service-title mt-4 mb-3 f-18"><b>Coming Soon</b></h4>
                        <p class="service-subtitle mb-4 f-15">Look forward to our next service</p>
                        <a href="<?php echo $BaseURL ?>" target="_blank" class="read-more">Open<span class="right-icon ml-2">&#8594;</span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="footer" style="background-image: url(dist/images/hero-1-bg-img.png)">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="mb-5">
                        <img src="dist/images/logo.png" alt="" class="" height="50">
                        <p class="text-white-50 my-4">Build and grow your dream server with us</p>
                        <a href="#" class="text-white-70"><i class="icon mr-1" data-feather="instagram"></i> Join Us In Instagram</a>
                    </div>
                </div>
                <div class="col-lg-7 offset-lg-1">
                    <div class="row">
                        <div class="col-md-4">
                            <h4 class="text-white f-22 font-weight-normal mb-3">Menu</h4>
                            <ul class="list-unstyled footer-sub-menu">
                                <li><a href="<?php echo $BaseURL ?>" class="footer-link">Home</a></li>
                                <li><a href="#" class="footer-link">Services</a></li>
                            </ul>
                        </div>
                        <div class="col-md-4">
                            <h4 class="text-white f-22 font-weight-normal mb-3">Services</h4>
                            <ul class="list-unstyled footer-sub-menu">
                                <li><a href="<?php echo $BaseURL.'phpmyadmin/' ?>" class="footer-link">PhpMyAdmin</a></li>
                                <li><a href="<?php echo $BaseURL.'filemanager/' ?>" class="footer-link">File Manager</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center mt-5">
                        <p class="text-white-50 f-15 mb-0">© <script>document.write(new Date().getFullYear())</script> ##DOMAIN##. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="dist/js/jquery.min.js"></script>
    <script src="dist/js/bootstrap.bundle.min.js"></script>
    <script src="dist/js/scrollspy.min.js"></script>
    <script src="dist/js/jquery.easing.min.js"></script>
    <script src="dist/js/feather.min.js"></script>
    <script src="dist/js/owl.carousel.min.js"></script>
    <script src="dist/js/app.js"></script>

    <script>
        feather.replace()
    </script>

</body>
</html>